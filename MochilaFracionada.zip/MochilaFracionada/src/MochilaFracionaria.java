// Classe que implementa o algoritmo de ordenação merge sort para os itens
class MochilaFracionaria {
    // Método que implementa o merge sort
    public static void mergeSort(Item[] itens, int inicio, int fim) {
        if (inicio < fim) { // Verifica se há mais de um elemento no intervalo
            int meio = (inicio + fim) / 2; // Calcula o índice do meio
            mergeSort(itens, inicio, meio); // Ordena a metade esquerda
            mergeSort(itens, meio + 1, fim); // Ordena a metade direita
            merge(itens, inicio, meio, fim); // Junta as duas metades ordenadas
        }
    }

    // Método que junta dois subarrays ordenados em um único array
    private static void merge(Item[] itens, int inicio, int meio, int fim) {
        int tamanhoEsquerda = meio - inicio + 1; // Tamanho do subarray esquerdo
        int tamanhoDireita = fim - meio; // Tamanho do subarray direito

        // Cria arrays temporários para armazenar os subarrays
        Item[] esquerda = new Item[tamanhoEsquerda];
        Item[] direita = new Item[tamanhoDireita];

        // Copia os elementos para os arrays temporários
        for (int i = 0; i < tamanhoEsquerda; i++) {
            esquerda[i] = itens[inicio + i];
        }
        for (int j = 0; j < tamanhoDireita; j++) {
            direita[j] = itens[meio + 1 + j];
        }

        int i = 0, j = 0; // Índices para iterar nos subarrays esquerdo e direito
        int k = inicio; // Índice para o array original

        // Junta os elementos dos subarrays em ordem decrescente de valor por peso
        while (i < tamanhoEsquerda && j < tamanhoDireita) {
            if (esquerda[i].valorPorPeso >= direita[j].valorPorPeso) {
                itens[k] = esquerda[i];
                i++;
            } else {
                itens[k] = direita[j];
                j++;
            }
            k++;
        }

        // Copia os elementos restantes do subarray esquerdo, se houver
        while (i < tamanhoEsquerda) {
            itens[k] = esquerda[i];
            i++;
            k++;
        }

        // Copia os elementos restantes do subarray direito, se houver
        while (j < tamanhoDireita) {
            itens[k] = direita[j];// Adiciona o elemento atual do subarray direito ao array combinado.
            j++; // Avança para o próximo elemento no subarray direito.
            k++; // Avança para a próxima posição no array combinado.
        }
    }
}
