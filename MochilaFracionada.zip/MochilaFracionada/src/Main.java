public class Main {
    public static void main(String[] args) {
        // Define os itens com seus pesos e valores
        Item[] itens = {
                new Item(10, 60),
                new Item(20, 100),
                new Item(30, 120),
                new Item(5, 30),
                new Item(20, 100),
                new Item(15, 90),
                new Item(25, 70),
                new Item(10, 40),
        };

        double capacidadeMochila = 50; // Define a capacidade máxima da mochila

        // Ordena os itens com base no valor por peso em ordem decrescente
        MochilaFracionaria.mergeSort(itens, 0, itens.length - 1);

        // Imprime os itens ordenados por valor por peso
        //System.out.println("Itens ordenados por valor por peso:");
        //for (Item item : itens) {
           // System.out.println("Peso: " + item.peso + ", Valor: " + item.valor + ", Valor por Peso: " + item.valorPorPeso);
        //}

        // Calcula o valor máximo que pode ser colocado na mochila
        double valorTotal = MochilaResolver.resolver(itens, capacidadeMochila);

        // Imprime o valor total calculado
        System.out.println("\nValor total na mochila: $" + valorTotal);
    }
}