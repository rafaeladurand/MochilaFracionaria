class MochilaResolver {
    // Método para calcular o valor total que pode ser colocado na mochila
    public static double resolver(Item[] itens, double capacidade) {
        double valorTotal = 0; // Valor total acumulado

        System.out.println("Itens adicionados na mochila:");

        // Itera pelos itens para adicioná-los à mochila
        for (Item item : itens) {
            if (capacidade == 0) { // Se a capacidade da mochila acabou, encerra o loop
                break;
            }

            // Determina o quanto do peso do item pode ser adicionado à mochila
            double pesoAdicionado = Math.min(item.peso, capacidade);
            if (pesoAdicionado > 0) {
                // Imprime informações sobre o peso e valor do item adicionado
                System.out.println("Peso: " + pesoAdicionado + ", Valor: " + (pesoAdicionado * item.valorPorPeso));
            }

            // Calcula o valor adicionado com base no peso e valor por peso
            valorTotal += pesoAdicionado * item.valorPorPeso;

            // Reduz a capacidade disponível da mochila
            capacidade -= pesoAdicionado;
        }

        // Retorna o valor total calculado
        return valorTotal;
    }
}