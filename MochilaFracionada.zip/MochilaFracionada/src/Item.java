// Classe que representa um item com peso, valor e valor por peso
class Item {
    double peso; // Peso do item
    double valor; // Valor do item
    double valorPorPeso; // Valor por unidade de peso do item

    // Construtor que inicializa os valores do item
    public Item(double peso, double valor) {
        this.peso = peso;
        this.valor = valor;
        this.valorPorPeso = valor / peso; // Calcula o valor por peso
    }
}